from flask import Blueprint, request, jsonify,send_file
import json
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
from reportlab.lib import colors
from io import BytesIO
import ast,os
from src.gpt_utilities import get_completion
from variable_loader import llm_global,font_name
from langchain_core.prompts import ChatPromptTemplate

ai_interview_bp = Blueprint('ai_interview_bp', __name__)

@ai_interview_bp.route('/generate_scorecard', methods=['POST'])
def generate_scorecard():
    if request.content_type == 'application/json':
        conversation = json.dumps(request.json["conversation"])

        prompt = '''
        Assess the following interview conversation between an interviewer (assistant) and a candidate (user). Based on the candidate's responses, generate a scorecard evaluating the candidate on three key parameters:

        1. **Technical Knowledge**
        2. **Understanding of the Job Description**
        3. **Candidate's Experience**

        For each parameter, assign a numerical score out of 10 (where 10 is the highest). Calculate the total score by summing the individual scores of the three parameters.

        **Important Requirements:**

        - **Output Format:** The scorecard must be presented strictly as a list of lists in the following format:
        [ ["Criteria", "Score"], ["Technical Knowledge", "X/10"], ["Understanding of Job Description", "Y/10"], ["Candidate's Experience", "Z/10"] ]

        
        - Replace `X`, `Y`, and `Z` with the respective numerical scores.
        - **Do not** include any additional text, explanations, or formatting outside of this structure.
        - Ensure that the scores (`X`, `Y`, `Z`) are **numbers only** and **do not** include any extra characters or annotations besides `/10`.

        - **Example Output:**
        [ ["Criteria", "Score"], ["Technical Knowledge", "8/10"], ["Understanding of Job Description", "7/10"], ["Candidate's Experience", "9/10"] ]

        
        **Conversation:**
        [Conversation] '''

        prompt = prompt.replace("[Conversation]", conversation)
        response = get_completion("You are an AI assistant who is tasked in assessing the interview.",prompt)
        print(response)
        print(type(response))
        list_data = ast.literal_eval(response)
        print(list_data)

        
        packet = BytesIO()
        pdf = SimpleDocTemplate(packet, pagesize=letter)

        # Create a table and apply style
        table = Table(list_data)
        style = TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTSIZE', (0, 0), (-1, -1), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.white),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ])
        table.setStyle(style)
        pdf.build([table])
        packet.seek(0)
        return send_file(packet, mimetype='application/pdf', as_attachment=True, download_name="Scorecard.pdf")
    
@ai_interview_bp.route('/ask_llm', methods=['POST'])
def ask_llm():
    if request.content_type == 'application/json':
        messages : list = request.json['messages']
        
        for i in range(len(messages)):
            messages[i] = tuple(messages[i])

        user_text = request.json.get('user_text')
        if user_text:
            messages.append(('user', user_text))

        prompt = ChatPromptTemplate.from_messages(messages)
        chain = prompt | llm_global

        result = chain.invoke({'input': user_text})
        messages.append(('assistant', result.content))
        for i in range(len(messages)):
            messages[i] = list(messages[i])
        return jsonify(messages)
    return 'Invalid content type', 429