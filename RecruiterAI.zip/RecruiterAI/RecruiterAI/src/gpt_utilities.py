from variable_loader import deployment_name,endpoint,azure_api_key,version
from langchain_openai import AzureOpenAI
from langchain_community.callbacks import get_openai_callback
from src.utilities import currency_converter_usd_to_inr
from variable_loader import llm_global
import json

def get_result_from_omni(prompt,combined_text):
    messages = [
        {"role": "system", "content": prompt},
        {"role": "user", "content": combined_text},
    ]
    try:
        with get_openai_callback() as cb:
            ai_msg = llm_global.invoke(messages)
            cost = float(format(cb.total_cost, '.6f'))
            try:
                output = currency_converter_usd_to_inr(cost)
                parsed_data = json.loads(output)
                converted_value = parsed_data["converted"]
                print("Total Cost (INR): ₹" + str(converted_value))
            except Exception as e:
                print(f"Currency conversion failed: {e}")
                output = "Conversion Error"
    except Exception as e:
        print(f"Error invoking LLM or calculating cost: {e}")
        return "Error occurred while generating a response."
    return ai_msg.content

def get_completion(system_message,prompt):
    messages = [
        {"role": "system", "content": system_message},
        {"role": "user", "content": prompt},
    ]
    try:
        with get_openai_callback() as cb:
            ai_msg = llm_global.invoke(messages)
            cost = float(format(cb.total_cost, '.6f'))
            try:
                output = currency_converter_usd_to_inr(cost)
                parsed_data = json.loads(output)
                converted_value = parsed_data["converted"]
                print("Total Cost (INR): ₹" + str(converted_value))
            except Exception as e:
                print(f"Currency conversion failed: {e}")
                output = "Conversion Error"
    except Exception as e:
        print(f"Error invoking LLM or calculating cost: {e}")
        return "Error occurred while generating a response."
    return ai_msg.content


    