'use strict';

const heygen_API = {
  apiKey: 'MmJiMjI3M2EzMzU4NDE3NmEyMDYwN2E2MTM4ZDIyZDgtMTcxNTc1NTI4MA==',
  serverUrl: 'https://api.heygen.com',
};

const statusElement = document.querySelector('#status');
const apiKey = heygen_API.apiKey;
const SERVER_URL = heygen_API.serverUrl;
// const avatar_id = "Anna_public_3_20240108";
const avatar_id = "Angela-inblackskirt-20220820";
const voice_id = "a22a7a8cd45042ad83e9bb9203e1a84b";

const loader = document.querySelector('#vdoLoader');
const cogSvcRegion = "southeastasia";
const cogSvcSubKey = "75ade8c25a2d42ada34b3b7146ccab43";
var messages = [];
var conversation = [];
var primePrompt = null;
var extractedCV = null;
var extractedJD = null;
var init_message = null;
var bot_started = false;

if (!apiKey || !SERVER_URL) {
  alert('Please enter your API key and server URL in the api.json file');
}

let sessionInfo = null;
let peerConnection = null;
let isMicrophoneActive = false;
let speechRecognizer;
const taskInput = document.querySelector('#taskInput');
const talkBtn = document.querySelector('#talkBtn');
const scorecard = document.getElementById('reportDownloadLink');

// Define the talkHandler function
async function talkHandler() {
  const prompt = taskInput.value.trim();
  if (!prompt) {
    updateStatus('Please enter a valid input before sending.');
    return;
  }
  // updateStatus('Talking to LLM... please wait');
  try {
    updateStatus(`You: ${prompt}`);
    taskInput.value = '';
    const response = await talkToOpenAI(prompt);
    // console.log(prompt)
    console.log(response)

    if (response && response.length > 0) {
      await repeat(sessionInfo.session_id, response[response.length - 1][1]);
      // updateStatus('LLM response sent successfully');
      updateStatus(`Anny: ${response[response.length - 1][1]}`);
    } else {
      console.log('Failed to get a response from AI')
      // updateStatus('Failed to get a response from AI');
    }
    // conversation = response
    console.log('Response from OpenAI:', response);
    // Do something with the responseText, e.g., update a UI element
  } catch (error) {
    console.error('Error talking to OpenAI:', error);
    // updateStatus('Failed to get a response from OpenAI.');
  }
}

function updateStatus(message) {
  statusElement.innerHTML += message + '<br>';
  statusElement.scrollTop = statusElement.scrollHeight;
}

function initSpeechSDK() {
  const speechConfig = SpeechSDK.SpeechConfig.fromSubscription(cogSvcSubKey, cogSvcRegion);
  const audioConfig = SpeechSDK.AudioConfig.fromDefaultMicrophoneInput();
  speechRecognizer = new SpeechSDK.SpeechRecognizer(speechConfig, audioConfig);

  speechRecognizer.recognized = async (s, e) => {
    if (e.result.reason === SpeechSDK.ResultReason.RecognizedSpeech) {
      const userQuery = e.result.text.trim();
      if (userQuery !== '') {
        await talkMicHandler(userQuery);
      }
    }
  };
}

// Function to handle user queries through microphone
async function talkMicHandler(userQuery) {
  updateStatus(`You: ${userQuery}`);
  if (!sessionInfo) {
    updateStatus('Please create a connection first');
    return;
  }

  // updateStatus('Talking to LLM... please wait');

  try {
    const response = await talkToOpenAI(userQuery);
    response[response.length - 1][1]
    if (response && response.length > 0) {
      await repeat(sessionInfo.session_id, response[response.length - 1][1]);
      // updateStatus('LLM response sent successfully');
      updateStatus(`Anny: ${response[response.length - 1][1]}`);
    } else {
      console.log('Failed to get a response from AI')
      // updateStatus('Failed to get a response from AI');
    }
  } catch (error) {
    console.error('Error talking to AI:', error);
    // updateStatus('Error talking to AI');
  }
}

document.querySelector('#talkBtnMic').addEventListener('click', () => {
  if (isMicrophoneActive) {
    stopMicrophone();
  } else {
    startMicrophone();
  }
});

document.querySelector('#introduce').style.display = 'none';
document.querySelector('#introduce').addEventListener('click', () => {
  repeat(sessionInfo.session_id, "Hello! I am Jenny, your mitsubishi materials assistant. How may I assist you today?");
});

function startMicrophone() {
  speechRecognizer.startContinuousRecognitionAsync(() => {
    isMicrophoneActive = true;
    document.querySelector('#talkBtnMic').innerHTML = '<svg viewBox="0 0 384 512" style="width:1.2vw; fill: white;"><path d="M192 0C139 0 96 43 96 96V256c0 53 43 96 96 96s96-43 96-96V96c0-53-43-96-96-96zM64 216c0-13.3-10.7-24-24-24s-24 10.7-24 24v40c0 89.1 66.2 162.7 152 174.4V464H120c-13.3 0-24 10.7-24 24s10.7 24 24 24h72 72c13.3 0 24-10.7 24-24s-10.7-24-24-24H216V430.4c85.8-11.7 152-85.3 152-174.4V216c0-13.3-10.7-24-24-24s-24 10.7-24 24v40c0 70.7-57.3 128-128 128s-128-57.3-128-128V216z"/></svg>';
    // updateStatus('Microphone started. Speak now...');
  }, err => {
    console.error('Error starting microphone recognition:', err);
    // updateStatus('Error starting microphone recognition');
  });
}

function stopMicrophone() {
  speechRecognizer.stopContinuousRecognitionAsync(() => {
    isMicrophoneActive = false;
    document.querySelector('#talkBtnMic').innerHTML = '<svg viewBox="0 0 640 512" style="width:2vw; fill: white;"><path d="M38.8 5.1C28.4-3.1 13.3-1.2 5.1 9.2S-1.2 34.7 9.2 42.9l592 464c10.4 8.2 25.5 6.3 33.7-4.1s6.3-25.5-4.1-33.7L472.1 344.7c15.2-26 23.9-56.3 23.9-88.7V216c0-13.3-10.7-24-24-24s-24 10.7-24 24v40c0 21.2-5.1 41.1-14.2 58.7L416 300.8V96c0-53-43-96-96-96s-96 43-96 96v54.3L38.8 5.1zm362.5 407l-43.1-33.9C346.1 382 333.3 384 320 384c-70.7 0-128-57.3-128-128v-8.7L144.7 210c-.5 1.9-.7 3.9-.7 6v40c0 89.1 66.2 162.7 152 174.4V464H248c-13.3 0-24 10.7-24 24s10.7 24 24 24h72 72c13.3 0 24-10.7 24-24s-10.7-24-24-24H344V430.4c20.4-2.8 39.7-9.1 57.3-18.2z"/></svg>';
    // updateStatus('Microphone stopped.');
  }, err => {
    console.error('Error stopping microphone recognition:', err);
    // updateStatus('Error stopping microphone recognition');
  });
}

async function createNewSession() {
  // updateStatus('Creating new session... please wait');
  sessionInfo = await newSession('low', avatar_id, voice_id);
  const { sdp: serverSdp, ice_servers2: iceServers } = sessionInfo;

  peerConnection = new RTCPeerConnection({ iceServers: iceServers });
  peerConnection.ontrack = event => {
    if (event.track.kind === 'audio' || event.track.kind === 'video') {
      document.querySelector('#mediaElement').srcObject = event.streams[0];
    }
  };

  peerConnection.onicecandidate = ({ candidate }) => {
    if (candidate) {
      handleICE(sessionInfo.session_id, candidate.toJSON());
    }
  };

  const remoteDescription = new RTCSessionDescription(serverSdp);
  await peerConnection.setRemoteDescription(remoteDescription);

  // updateStatus('Session creation completed');
  // updateStatus('Now you can click the start button to start the stream');
}

async function startAndDisplaySession() {
  loader.style.display = "flex";

  if (!sessionInfo) {
    updateStatus('Please create a connection first');
    return;
  }

  // updateStatus('Starting session... please wait');

  const localDescription = await peerConnection.createAnswer();
  await peerConnection.setLocalDescription(localDescription);

  await startSession(sessionInfo.session_id, localDescription);

  loader.style.display = "none";
  updateStatus('Session started successfully');
  
  setTimeout(()=>{
    document.getElementById('removeBGCheckbox').checked = true;
    removeBG();
    if(init_message) {
      updateStatus(`Anny: ${init_message}`);
      repeat(sessionInfo.session_id, init_message);
    }
    else bot_started = true;
    // repeat(sessionInfo.session_id, "Hello! I am Jenny, your mitsubishi materials assistant. How may I assist you today?");
   },3000);
}

// Event listeners for other buttons
document.querySelector('#newBtn').addEventListener('click', createNewSession);

document.querySelector('#startBtn').addEventListener('click', ()=>{
  startAndDisplaySession();

  primePrompt = `You are a bot called Amy that conducts candidate interviews according to their resume and job description.
  Conduct an interview for this job description: ${extractedJD}.
  Begin by welcoming the candidate to the interview and start by asking, "Introduce yourself."
  Then, ask questions related to the resume: ${extractedCV} and the job description.
  After each answer, carefully evaluate the response on these parameters: technical knowledge, job description, and candidate's experience.
  Ask relevant follow-up questions to probe deeper into specific areas. If the response is relevant, acknowledge it and proceed with a related follow-up.
  Limit your responses to 30 words.
  If the candidate's response is irrelevant to the question asked, provide the correct answer.
  Assess the candidate on all parameters and ensure to cover them in 7-8 questions or within 10 minutes.
  Complete the interview by thanking the candidate and informing them that further details will be provided via email.

  Note - Avoid using any special characters in your responses.`

  messages.push(['system', primePrompt])

  fetch('/ai_interview/ask_llm', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({messages: messages})
  }).then(response => {
    if(response.ok)
      return response.json()
    else return []
  }).then(resp_messages=>{
    console.log(resp_messages)
    if(resp_messages.length === 0) return;

    messages = resp_messages;
    let gpt_resp = resp_messages[resp_messages.length - 1]
    console.log(gpt_resp)

    if(bot_started){
      updateStatus(`Anny: ${gpt_resp[1]}`)
      repeat(sessionInfo.session_id, gpt_resp[1]);
    }else{
      init_message = gpt_resp[1];
    }
  })
});
talkBtn.addEventListener('click', talkHandler);
window.onload = async function () {
  try {
    initSpeechSDK();
    await createNewSession();
  } catch (error) {
    console.error('Error during session setup:', error);
    // updateStatus('Error during session setup. Please check the console for more details.');
  }
};

// Function to create a new session
async function newSession(quality, avatar_name, voice_id) {
  const response = await fetch(`${SERVER_URL}/v1/streaming.new`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Api-Key': apiKey,
    },
    body: JSON.stringify({
      quality,
      avatar_name,
      voice: {
        voice_id: voice_id,
      },
    }),
  });

  if (response.status === 500) {
    console.error('Server error');
    // updateStatus('Server Error. Please ask the staff if the service has been turned on');
    throw new Error('Server error');
  } else {
    const data = await response.json();
    return data.data;
  }
}

// Function to start the session
async function startSession(session_id, sdp) {
  loader.style.display = "flex";
  const response = await fetch(`${SERVER_URL}/v1/streaming.start`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Api-Key': apiKey,
    },
    body: JSON.stringify({ session_id, sdp }),
  });

  if (response.status === 500) {
    console.error('Server error');
    // updateStatus('Server Error. Please ask the staff if the service has been turned on');
    throw new Error('Server error');
  } else {
    const data = await response.json();
    return data.data;
  }
}

// Function to handle ICE candidates
async function handleICE(session_id, candidate) {
  const response = await fetch(`${SERVER_URL}/v1/streaming.ice`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Api-Key': apiKey,
    },
    body: JSON.stringify({ session_id, candidate }),
  });

  if (response.status === 500) {
    console.error('Server error');
    // updateStatus('Server Error. Please ask the staff if the service has been turned on');
    throw new Error('Server error');
  } else {
    const data = await response.json();
    return data;
  }
}

// Function to talk to OpenAI
async function talkToOpenAI(prompt) {
  const response = await fetch('/ai_interview/ask_llm', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ messages: messages, user_text: prompt }),
  });

  if (response.status === 500) {
    console.error('Server error');
    // updateStatus('Server Error. Please make sure to set the OpenAI API key');
    throw new Error('Server error');
  } else {
    const data = await response.json();
    if(!data || data.length === 0)
      return []
    messages = data;
    console.log("conversation")
    console.log(messages)
    conversation = messages
    return data;
  }
}

// Function to repeat the text
async function repeat(session_id, text) {
  const response = await fetch(`${SERVER_URL}/v1/streaming.task`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Api-Key': apiKey,
    },
    body: JSON.stringify({ session_id, text }),
  });

  if (response.status === 500) {
    console.error('Server error');
    // updateStatus('Server Error. Please ask the staff if the service has been turned on');
    throw new Error('Server error');
  } else {
    const data = await response.json();
    return data.data;
  }
}

// Function to stop the session
async function stopSession(session_id) {
  console.log(messages)
  const response = await fetch(`${SERVER_URL}/v1/streaming.stop`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Api-Key': apiKey,
    },
    body: JSON.stringify({ session_id }),
  });

  if (response.status === 500) {
    console.error('Server error');
    // updateStatus('Server Error. Please ask the staff for help');
    throw new Error('Server error');
  } else {
    const data = await response.json();
    return data.data;
  }
}

const removeBGCheckbox = document.querySelector('#removeBGCheckbox');
removeBGCheckbox.addEventListener('change', removeBG);
function removeBG(){
  console.log('removeBG is triggered');
  const isChecked = true;//document.querySelector('#removeBGCheckbox').checked;
  if (isChecked && !sessionInfo) {
    updateStatus('Please create a connection first');
    document.querySelector('#removeBGCheckbox').checked = false;
    return;
  }

  if (isChecked && !mediaCanPlay) {
    updateStatus('Please wait for the video to load');
    document.querySelector('#removeBGCheckbox').checked = false;
    return;
  }

  if (isChecked) {
    hideElement(mediaElement);
    showElement(canvasElement);
    renderCanvas();
  } else {
    hideElement(canvasElement);
    showElement(mediaElement);
    renderID++;
  }
}

let renderID = 0;

function renderCanvas() {
  if (!document.querySelector('#removeBGCheckbox').checked) return;
  hideElement(mediaElement);
  showElement(canvasElement);

  canvasElement.classList.add('show');

  const curRenderID = Math.trunc(Math.random() * 1000000000);
  renderID = curRenderID;

  const ctx = canvasElement.getContext('2d', { willReadFrequently: true });

  if (document.querySelector('#bgInput').value) {
    canvasElement.parentElement.style.background = document.querySelector('#bgInput').value.trim();
  }

  function processFrame() {
    if (!document.querySelector('#removeBGCheckbox').checked) return;
    if (curRenderID !== renderID) return;

    canvasElement.width = mediaElement.videoWidth;
    canvasElement.height = mediaElement.videoHeight;

    ctx.drawImage(mediaElement, 0, 0, canvasElement.width, canvasElement.height);
    const imageData = ctx.getImageData(0, 0, canvasElement.width, canvasElement.height);
    const data = imageData.data;

    for (let i = 0; i < data.length; i += 4) {
      const red = data[i];
      const green = data[i + 1];
      const blue = data[i + 2];

      if (isCloseToGreen([red, green, blue])) {
        data[i + 3] = 0;
      }
    }

    ctx.putImageData(imageData, 0, 0);

    requestAnimationFrame(processFrame);
  }

  processFrame();
}

function isCloseToGreen([red, green, blue]) {
  return green > 90 && red < 90 && blue < 90;
}

function hideElement(element) {
  element.classList.add('hide');
  element.classList.remove('show');
}

function showElement(element) {
  element.classList.add('show');
  element.classList.remove('hide');
}

const mediaElement = document.querySelector('#mediaElement');
let mediaCanPlay = false;

mediaElement.onloadedmetadata = () => {
  mediaCanPlay = true;
  mediaElement.play();
};

const canvasElement = document.querySelector('#canvasElement');


window.addEventListener('message', async function(event) {
  if (event.origin !== window.location.origin) {
      // Ignore messages from different origins for security reasons
      return;
  }

  const data = event.data;
  console.log('Received data:', data);
  document.querySelector('#startBtn').style.display = 'none';
  // Handle the received data (jobTitle and skills)
  extractedCV = data.cv;
  extractedJD = data.jd;

  await startAndDisplaySession();

  primePrompt = `You are a bot called Amy that conducts candidate interviews according to their resume and job description.
  Conduct an interview for this job description: ${extractedJD}.
  Begin by welcoming the candidate to the interview and start by asking, "Introduce yourself."
  Then, ask questions related to the resume: ${extractedCV} and the job description.
  After each answer, carefully evaluate the response on these parameters: technical knowledge, job description, and candidate's experience.
  Ask relevant follow-up questions to probe deeper into specific areas. If the response is relevant, acknowledge it and proceed with a related follow-up.
  Limit your responses to 30 words.
  If the candidate's response is irrelevant to the question asked, provide the correct answer.
  Assess the candidate on all parameters and ensure to cover them in 7-8 questions or within 10 minutes.
  Complete the interview by thanking the candidate and informing them that further details will be provided via email. 

  Note - Avoid using any special characters in your responses.`

  messages.push(['system', primePrompt])

  await this.fetch('/ai_interview/ask_llm', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({messages: messages})
  }).then(response => {
    if(response.ok)
      return response.json()
    else return []
  }).then(resp_messages=>{
    console.log(resp_messages)
    if(resp_messages.length === 0) return;

    messages = resp_messages;
    let gpt_resp = resp_messages[resp_messages.length - 1]
    console.log(gpt_resp)

    if(bot_started){
      updateStatus(`Anny: ${gpt_resp[1]}`)
      repeat(sessionInfo.session_id, gpt_resp[1]);
    }else{
      init_message = gpt_resp[1];
    }
  })

});

scorecard.addEventListener("click", () => {

  fetch('/ai_interview/generate_scorecard', {
    method: 'POST',  // Use POST to send data
    headers: {
        'Content-Type': 'application/json',  // Specify that we're sending JSON
    },
    body: JSON.stringify({ conversation: conversation}),
  })
  .then(response => {
      if (response.ok) {
          return response.blob();  // Convert the response to a Blob object
      } else {
          throw new Error('Failed to fetch the scorecard');
      }
  })
  .then(blob => {
      const url = window.URL.createObjectURL(new Blob([blob]));  // Create a URL for the Blob
      const link = document.createElement('a');  // Create a temporary link element
      link.href = url;
      // Get today's date
      const today = new Date();
      // Format the date as DD/MM/YYYY
      const formattedDate =  String(today.getDate()).padStart(2, '0') + '/' + String(today.getMonth() + 1).padStart(2, '0') + '/' + today.getFullYear() ;
      link.setAttribute('download', 'Scorecard_' + formattedDate + '.pdf');  // Set the download attribute with the file name
      document.body.appendChild(link);  // Append the link to the DOM
      link.click();  // Trigger the click event to download the file
      link.parentNode.removeChild(link);  // Clean up the DOM by removing the link
  })
  .catch(error => {
      console.error('Error while downloading the PDF:', error);
  });
})