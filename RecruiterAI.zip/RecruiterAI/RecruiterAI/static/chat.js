// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license.

// Global objects
var speechRecognizer
var avatarSynthesizer
var peerConnection
var messages = []
var messageInitiated = false
var dataSources = []
var sentenceLevelPunctuations = ['.', '?', '!', ':', ';', '。']
var enableQuickReply = true
var quickReplies = ['Let me take a look.', 'Let me check.', 'One moment, please.', 'I am checking on your input']
var byodDocRegex = new RegExp(/\[doc(\d+)\]/g)
var isSpeaking = false
var spokenTextQueue = []
var sessionActive = false
var lastSpeakTime
const todays_date = new Date();
const cogSvcRegion = "southeastasia";
const cogSvcSubKey = "75ade8c25a2d42ada34b3b7146ccab43";
const talkingAvatarCharacter = "lisa";
const talkingAvatarStyle = "casual-sitting";
const azureOpenAIEndpoint = "https://gpt-models-lab.openai.azure.com/";
const azureOpenAIApiKey = "Cttk29CVLMbtXAGLY5oggcQRTmQeVaCOyKUoApewcYcuXRAuZ9UBJQQJ99AKACYeBjFXJ3w3AAABACOGqFF0";
const azureOpenAIDeploymentName = "gpt-4o";
const iceServerUrl = "turn:relay.communication.microsoft.com:3478";
const iceServerUsername = "BQAASECVnQAB2nbGcH26huI2stKoBC1041N/UfFEN1QAAAAMARB7CO/KckhBibz/vxr/AbuAAhAAAAAe1066OJnGWToNAIvrikSuBsiUiDHcvxH7+HwTPLfOB9o=";
const iceServerCredential = "V5/lYVxiCpVACoCMjAbVPPgr/hk=";
const azureCogSearchEndpoint = "https://search-servive-ih.search.windows.net";
const azureCogSearchApiKey = "AgPut2iepWf5KJDBDmiepD61UzwKnvCmaaguy93VxqAzSeCjWEcx";
const azureCogSearchIndexName = '';
const avatarttsVoice = "en-US-AvaMultilingualNeural";
let extractedCV = '';
let extractedJD = '';
const systemPrompt = `
You are a bot called Anny which conducts technical interviews for ${extractedJD} role. Start the conversation by congratulating the candidate for reaching till this round. Only ask related technical questions out of the CV provided ${extractedCV} and for the ${extractedJD} role one by one like an interview but don't let the candidate know if the answer's are correct or not. Ask maximum of 3 questions only. Restrict your responses to 30 words only.
`;
// Connect to avatar service
function connectAvatar() {
    if (cogSvcSubKey === '') {
        alert('Please fill in the subscription key of your speech resource.')
        return
    }
    const speechSynthesisConfig = SpeechSDK.SpeechConfig.fromSubscription(cogSvcSubKey, cogSvcRegion)
    speechSynthesisConfig.endpointId = document.getElementById('customVoiceEndpointId').value
    speechSynthesisConfig.speechSynthesisVoiceName = avatarttsVoice
    const avatarConfig = new SpeechSDK.AvatarConfig(talkingAvatarCharacter, talkingAvatarStyle)
    avatarConfig.customized = document.getElementById('customizedAvatar').checked
    avatarSynthesizer = new SpeechSDK.AvatarSynthesizer(speechSynthesisConfig, avatarConfig)
    avatarSynthesizer.avatarEventReceived = function (s, e) {
        var offsetMessage = ", offset from session start: " + e.offset / 10000 + "ms."
        if (e.offset === 0) {
            offsetMessage = ""
        }
        console.log("Event received: " + e.description + offsetMessage)
    }

    const speechRecognitionConfig = SpeechSDK.SpeechConfig.fromEndpoint(new URL(`wss://${cogSvcRegion}.stt.speech.microsoft.com/speech/universal/v2`), cogSvcSubKey)
    speechRecognitionConfig.setProperty(SpeechSDK.PropertyId.SpeechServiceConnection_LanguageIdMode, "Continuous")
    //Languages for speech to text translation
    var sttLocales = "en-US".split(',')
    // var sttLocales = "en-US,hi-IN,te-IN,ta-IN,mr-IN,kn-IN,ml-IN,gu-IN,bn-IN".split(',') 
    // var sttLocales = "en-US,en-AU,en-CA,en-IN,en-GB,fr-CA,de-DE,es-ES,fr-FR,it-IT,ja-JP,zh-CN,pt-BR,es-MX".split(',')
    var autoDetectSourceLanguageConfig = SpeechSDK.AutoDetectSourceLanguageConfig.fromLanguages(sttLocales)
    speechRecognizer = SpeechSDK.SpeechRecognizer.FromConfig(speechRecognitionConfig, autoDetectSourceLanguageConfig, SpeechSDK.AudioConfig.fromDefaultMicrophoneInput())

    if (azureOpenAIEndpoint === '' || azureOpenAIApiKey === '' || azureOpenAIDeploymentName === '') {
        alert('Please fill in the Azure OpenAI endpoint, API key and deployment name.')
        return
    }
    dataSources = []
    if (document.getElementById('enableByod').checked) {
        if (azureCogSearchEndpoint === "" || azureCogSearchApiKey === "" || azureCogSearchIndexName === "") {
            alert('Please fill in the Azure Cognitive Search endpoint, API key and index name.')
            return
        } else {
            setDataSources(azureCogSearchEndpoint, azureCogSearchApiKey, azureCogSearchIndexName)
        }
    }

    // Only initialize messages once
    if (!messageInitiated) {
        initMessages()
        messageInitiated = true
    }
    if (iceServerUrl === '' || iceServerUsername === '' || iceServerCredential === '') {
        alert('Please fill in the ICE server URL, username and credential.')
        return
    }

    document.getElementById('startSession').disabled = true
    document.getElementById('configuration').hidden = true
    document.getElementById('btn-type-msg').style.display = "flex";
    document.getElementById('showTypeMessageCheckbox').style.display = "flex";
    setupWebRTC(iceServerUrl, iceServerUsername, iceServerCredential)


}

// Disconnect from avatar service
function disconnectAvatar() {
    if (avatarSynthesizer !== undefined) {
        avatarSynthesizer.close()
    }

    if (speechRecognizer !== undefined) {
        speechRecognizer.stopContinuousRecognitionAsync()
        speechRecognizer.close()
    }
    // document.getElementById('showTypeMessageCheckbox').style.display = "none";
    document.getElementById('btn-type-msg').style.display = "none";
    sessionActive = false
}

// Setup WebRTC
function setupWebRTC(iceServerUrl, iceServerUsername, iceServerCredential) {
    // Create WebRTC peer connection
    peerConnection = new RTCPeerConnection({
        iceServers: [{
            urls: [iceServerUrl],
            username: iceServerUsername,
            credential: iceServerCredential
        }]
    })

    // Fetch WebRTC video stream and mount it to an HTML video element
    peerConnection.ontrack = function (event) {
        // Clean up existing video element if there is any
        remoteVideoDiv = document.getElementById('remoteVideo')
        for (var i = 0; i < remoteVideoDiv.childNodes.length; i++) {
            if (remoteVideoDiv.childNodes[i].localName === event.track.kind) {
                remoteVideoDiv.removeChild(remoteVideoDiv.childNodes[i])
            }
        }

        if (event.track.kind === 'audio') {
            let audioElement = document.createElement('audio')
            audioElement.id = 'audioPlayer'
            audioElement.srcObject = event.streams[0]
            audioElement.autoplay = true

            audioElement.onplaying = () => {
                console.log(`WebRTC ${event.track.kind} channel connected.`)
            }

            document.getElementById('remoteVideo').appendChild(audioElement)
        }

        if (event.track.kind === 'video') {
            document.getElementById('remoteVideo').style.width = '0.1px'
            if (!document.getElementById('useLocalVideoForIdle').checked) {
                document.getElementById('chatHistory').hidden = true
            }

            let videoElement = document.createElement('video')
            videoElement.id = 'videoPlayer'
            videoElement.srcObject = event.streams[0]
            videoElement.autoplay = true
            videoElement.playsInline = true

            videoElement.onplaying = () => {
                console.log(`WebRTC ${event.track.kind} channel connected.`)
                document.getElementById('microphone').disabled = false
                document.getElementById('stopSession').disabled = false
                document.getElementById('remoteVideo').style.width = '95%'
                document.getElementById('chatHistory').hidden = false
                document.getElementById('showTypeMessage').disabled = false

                if (document.getElementById('useLocalVideoForIdle').checked) {
                    document.getElementById('localVideo').hidden = true
                    if (lastSpeakTime === undefined) {
                        lastSpeakTime = new Date()
                    }
                }
                setTimeout(() => { sessionActive = true }, 5000) // Set session active after 5 seconds
            }

            document.getElementById('remoteVideo').appendChild(videoElement)
        }
    }

    // Make necessary update to the web page when the connection state changes
    peerConnection.oniceconnectionstatechange = e => {
        console.log("WebRTC status: " + peerConnection.iceConnectionState)
        if (peerConnection.iceConnectionState === 'disconnected') {
            if (document.getElementById('useLocalVideoForIdle').checked) {
                document.getElementById('localVideo').hidden = false
                document.getElementById('remoteVideo').style.width = '0.1px'
            }
        }
    }

    // Offer to receive 1 audio, and 1 video track
    peerConnection.addTransceiver('video', { direction: 'sendrecv' })
    peerConnection.addTransceiver('audio', { direction: 'sendrecv' })

    // start avatar, establish WebRTC connection
    avatarSynthesizer.startAvatarAsync(peerConnection).then((r) => {
        if (r.reason === SpeechSDK.ResultReason.SynthesizingAudioCompleted) {
            console.log("[" + (new Date()).toISOString() + "] Avatar started. Result ID: " + r.resultId)
        } else {
            console.log("[" + (new Date()).toISOString() + "] Unable to start avatar. Result ID: " + r.resultId)
            if (r.reason === SpeechSDK.ResultReason.Canceled) {
                let cancellationDetails = SpeechSDK.CancellationDetails.fromResult(r)
                if (cancellationDetails.reason === SpeechSDK.CancellationReason.Error) {
                    console.log(cancellationDetails.errorDetails)
                };

                console.log("Unable to start avatar: " + cancellationDetails.errorDetails);
            }
            document.getElementById('startSession').disabled = false;
            document.getElementById('configuration').hidden = false;
        }
    }).catch(
        (error) => {
            console.log("[" + (new Date()).toISOString() + "] Avatar failed to start. Error: " + error)
            document.getElementById('startSession').disabled = false
            document.getElementById('configuration').hidden = false
        }
    )
}

// Initialize messages
function initMessages() {
    messages = []
    if (dataSources.length === 0) {
        console.log("The dataSource is not present")
        let systemMessage = {
            role: 'system',
            content: systemPrompt
        }

        messages.push(systemMessage)
    }
    console.log("The dataSource is present")
}

// Set data sources for chat API
function setDataSources(azureCogSearchEndpoint, azureCogSearchApiKey, azureCogSearchIndexName) {
    let dataSource = {
        type: 'AzureCognitiveSearch',
        parameters: {
            endpoint: azureCogSearchEndpoint,
            key: azureCogSearchApiKey,
            indexName: azureCogSearchIndexName,
            semanticConfiguration: '',
            queryType: 'simple',
            fieldsMapping: {
                contentFieldsSeparator: '\n',
                contentFields: ['content'],
                filepathField: null,
                titleField: 'title',
                urlField: null
            },
            inScope: false, // if true, it will only restrict to user data provided.
            roleInformation: systemPrompt,
            strictness: 2,
            topNDocuments: 2
        }
    }
    dataSources.push(dataSource)
}

// Do HTML encoding on given text
function htmlEncode(text) {
    const entityMap = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;',
        '/': '&#x2F;'
    };

    return String(text).replace(/[&<>"'\/]/g, (match) => entityMap[match])
}

// Speak the given text
function speak(text, endingSilenceMs = 0) {
    if (isSpeaking) {
        spokenTextQueue.push(text)
        return
    }

    speakNext(text, endingSilenceMs)
}

function speakNext(text, endingSilenceMs = 0) {
    // let ttsVoice = document.getElementById('ttsVoice').value
    let ttsVoice = avatarttsVoice
    let ssml = `<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xmlns:mstts='http://www.w3.org/2001/mstts' xml:lang='en-US'><voice name='${ttsVoice}'><mstts:leadingsilence-exact value='0'/>${htmlEncode(text)}</voice></speak>`
    if (endingSilenceMs > 0) {
        ssml = `<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xmlns:mstts='http://www.w3.org/2001/mstts' xml:lang='en-US'><voice name='${ttsVoice}'><mstts:leadingsilence-exact value='0'/>${htmlEncode(text)}<break time='${endingSilenceMs}ms' /></voice></speak>`
    }

    lastSpeakTime = new Date()
    isSpeaking = true
    document.getElementById('stopSpeaking').disabled = false
    avatarSynthesizer.speakSsmlAsync(ssml).then(
        (result) => {
            if (result.reason === SpeechSDK.ResultReason.SynthesizingAudioCompleted) {
                console.log(`Speech synthesized to speaker for text [ ${text} ]. Result ID: ${result.resultId}`)
                lastSpeakTime = new Date()
            } else {
                console.log(`Error occurred while speaking the SSML. Result ID: ${result.resultId}`)
            }

            if (spokenTextQueue.length > 0) {
                speakNext(spokenTextQueue.shift())
            } else {
                isSpeaking = false
                document.getElementById('stopSpeaking').disabled = true
            }
        }).catch(
            (error) => {
                console.log(`Error occurred while speaking the SSML: [ ${error} ]`)

                if (spokenTextQueue.length > 0) {
                    speakNext(spokenTextQueue.shift())
                } else {
                    isSpeaking = false
                    document.getElementById('stopSpeaking').disabled = true
                }
            }
        )
}

function stopSpeaking() {
    spokenTextQueue = []
    avatarSynthesizer.stopSpeakingAsync().then(
        () => {
            isSpeaking = false
            document.getElementById('stopSpeaking').disabled = true
            console.log("[" + (new Date()).toISOString() + "] Stop speaking request sent.")
        }
    ).catch(
        (error) => {
            console.log("Error occurred while stopping speaking: " + error)
        }
    )
}

function handleUserQuery(userQuery) {
    let chatMessage = {
        role: 'user',
        content: userQuery
    }

    messages.push(chatMessage)
    let chatHistoryTextArea = document.getElementById('chatHistory')
    if (chatHistoryTextArea.innerHTML !== '' && !chatHistoryTextArea.innerHTML.endsWith('\n\n')) {
        chatHistoryTextArea.innerHTML += '\n\n'
    }

    chatHistoryTextArea.innerHTML += "User: " + userQuery + '\n\n'
    chatHistoryTextArea.scrollTop = chatHistoryTextArea.scrollHeight

    // Stop previous speaking if there is any
    if (isSpeaking) {
        stopSpeaking()
    }

    // For 'bring your data' scenario, chat API currently has long (4s+) latency
    // We return some quick reply here before the chat API returns to mitigate.
    if (dataSources.length > 0 && enableQuickReply) {
        speak(getQuickReply(), 1000)
    }
    let url = "{AOAIEndpoint}/openai/deployments/{AOAIDeployment}/chat/completions?api-version=2023-12-01-preview".replace("{AOAIEndpoint}", azureOpenAIEndpoint).replace("{AOAIDeployment}", azureOpenAIDeploymentName)
    let body = JSON.stringify({
        messages: messages,
        stream: true
    })

    if (dataSources.length > 0) {
        url = "{AOAIEndpoint}/openai/deployments/{AOAIDeployment}/extensions/chat/completions?api-version=2023-12-01-preview".replace("{AOAIEndpoint}", azureOpenAIEndpoint).replace("{AOAIDeployment}", azureOpenAIDeploymentName)
        body = JSON.stringify({
            dataSources: dataSources,
            messages: messages,
            stream: true,
            temperature: 0,
            top_p: 1.0
        })
    }

    let assistantReply = ''
    let toolContent = ''
    let spokenSentence = ''
    let displaySentence = ''

    fetch(url, {
        method: 'POST',
        headers: {
            'api-key': azureOpenAIApiKey,
            'Content-Type': 'application/json'
        },
        body: body
    })
        .then(response => {
            if (!response.ok) {
                throw new Error(`Chat API response status: ${response.status} ${response.statusText}`)
            }

            let chatHistoryTextArea = document.getElementById('chatHistory')
            chatHistoryTextArea.innerHTML += 'Interview Assistant: '

            const reader = response.body.getReader()

            // Function to recursively read chunks from the stream
            function read(previousChunkString = '') {
                return reader.read().then(({ value, done }) => {
                    // Check if there is still data to read
                    if (done) {
                        // Stream complete
                        return
                    }

                    // Process the chunk of data (value)
                    let chunkString = new TextDecoder().decode(value, { stream: true })
                    if (previousChunkString !== '') {
                        // Concatenate the previous chunk string in case it is incomplete
                        chunkString = previousChunkString + chunkString
                    }

                    if (!chunkString.endsWith('}\n\n') && !chunkString.endsWith('[DONE]\n\n')) {
                        // This is a incomplete chunk, read the next chunk
                        return read(chunkString)
                    }

                    chunkString.split('\n\n').forEach((line) => {
                        try {
                            if (line.startsWith('data:') && !line.endsWith('[DONE]')) {
                                const responseJson = JSON.parse(line.substring(5).trim())
                                let responseToken = undefined
                                if (dataSources.length === 0) {
                                    responseToken = responseJson.choices[0].delta.content
                                } else {
                                    let role = responseJson.choices[0].delta.role
                                    if (role === undefined && responseJson.choices[0].delta.context !== undefined) {
                                        role = responseJson.choices[0].delta.context.messages[0].role
                                    }
                                    if (role === 'tool') {
                                        toolContent = responseJson.choices[0].delta.context.messages[0].content
                                    } else {
                                        responseToken = responseJson.choices[0].delta.content
                                        if (responseToken !== undefined) {
                                            if (byodDocRegex.test(responseToken)) {
                                                responseToken = responseToken.replace(byodDocRegex, '').trim()
                                            }

                                            if (responseToken === '[DONE]') {
                                                responseToken = undefined
                                            }
                                        }
                                    }
                                }

                                if (responseToken !== undefined && responseToken !== null) {
                                    assistantReply += responseToken // build up the assistant message
                                    displaySentence += responseToken // build up the display sentence

                                    // console.log(`Current token: ${responseToken}`)

                                    if (responseToken === '\n' || responseToken === '\n\n') {
                                        speak(spokenSentence.trim())
                                        spokenSentence = ''
                                    } else {
                                        responseToken = responseToken.replace(/\n/g, '')
                                        spokenSentence += responseToken // build up the spoken sentence

                                        if (responseToken.length === 1 || responseToken.length === 2) {
                                            for (let i = 0; i < sentenceLevelPunctuations.length; ++i) {
                                                let sentenceLevelPunctuation = sentenceLevelPunctuations[i]
                                                if (responseToken.startsWith(sentenceLevelPunctuation)) {
                                                    speak(spokenSentence.trim())
                                                    spokenSentence = ''
                                                    break
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } catch (error) {
                            console.log(`Error occurred while parsing the response: ${error}`)
                            console.log(chunkString)
                        }
                    })

                    chatHistoryTextArea.innerHTML += `${displaySentence}`
                    chatHistoryTextArea.scrollTop = chatHistoryTextArea.scrollHeight
                    displaySentence = ''

                    // Continue reading the next chunk
                    return read()
                })
            }

            // Start reading the stream
            return read()
        })
        .then(() => {
            if (spokenSentence !== '') {
                speak(spokenSentence.trim())
                spokenSentence = ''
            }

            if (dataSources.length > 0) {
                let toolMessage = {
                    role: 'tool',
                    content: toolContent
                }

                messages.push(toolMessage)
            }

            let assistantMessage = {
                role: 'assistant',
                content: assistantReply
            }

            messages.push(assistantMessage)
        })
}

function getQuickReply() {
    return quickReplies[Math.floor(Math.random() * quickReplies.length)]
}

function checkHung() {
    // Check whether the avatar video stream is hung, by checking whether the video time is advancing
    let videoElement = document.getElementById('videoPlayer')
    if (videoElement !== null && videoElement !== undefined && sessionActive) {
        let videoTime = videoElement.currentTime
        setTimeout(() => {
            // Check whether the video time is advancing
            if (videoElement.currentTime === videoTime) {
                // Check whether the session is active to avoid duplicatedly triggering reconnect
                if (sessionActive) {
                    sessionActive = false
                    if (document.getElementById('autoReconnectAvatar').checked) {
                        console.log(`[${(new Date()).toISOString()}] The video stream got disconnected, need reconnect.`)
                        connectAvatar()
                    }
                }
            }
        }, 5000)
    }
}

function checkLastSpeak() {
    if (lastSpeakTime === undefined) {
        return
    }

    let currentTime = new Date()
    if (currentTime - lastSpeakTime > 15000) {
        if (document.getElementById('useLocalVideoForIdle').checked && sessionActive && !isSpeaking) {
            disconnectAvatar()
            document.getElementById('localVideo').hidden = false
            document.getElementById('remoteVideo').style.width = '0.1px'
            sessionActive = false
        }
    }
}

window.onload = () => {
    setInterval(() => {
        checkHung()
        checkLastSpeak()
    }, 5000) // Check session activity every 5 seconds
}

window.startSession = () => {
    document.getElementById('overlay-glass').style.display = 'none';
    if (document.getElementById('useLocalVideoForIdle').checked) {

        document.getElementById('startSession').disabled = true
        document.getElementById('configuration').hidden = true
        document.getElementById('microphone').disabled = false
        document.getElementById('stopSession').disabled = false
        document.getElementById('localVideo').hidden = false
        document.getElementById('remoteVideo').style.width = '0.1px'
        document.getElementById('chatHistory').hidden = false
        document.getElementById('showTypeMessage').disabled = false
        return
    }

    connectAvatar()
}

// window.addEventListener("load", startSession);

window.stopSession = () => {
    document.getElementById('startSession').disabled = false
    document.getElementById('microphone').disabled = true
    document.getElementById('stopSession').disabled = true
    document.getElementById('configuration').hidden = false
    document.getElementById('chatHistory').hidden = true
    document.getElementById('showTypeMessage').checked = false
    document.getElementById('showTypeMessage').disabled = true
    document.getElementById('userMessageBox').hidden = true
    if (document.getElementById('useLocalVideoForIdle').checked) {
        document.getElementById('localVideo').hidden = true
    }
    document.getElementById('overlay-glass').style.display = 'block';
    disconnectAvatar()
}

window.clearChatHistory = () => {
    document.getElementById('chatHistory').innerHTML = ''
    initMessages()
}

window.microphone = () => {
    if (document.getElementById('microphone').innerHTML === 'Stop Microphone') {
        // Stop microphone
        document.getElementById('microphone').disabled = true
        speechRecognizer.stopContinuousRecognitionAsync(
            () => {
                document.getElementById('microphone').innerHTML = 'Start Microphone'
                document.getElementById('microphone').disabled = false
            }, (err) => {
                console.log("Failed to stop continuous recognition:", err)
                document.getElementById('microphone').disabled = false
            })

        return
    }

    if (document.getElementById('useLocalVideoForIdle').checked) {
        if (!sessionActive) {
            connectAvatar()
        }

        setTimeout(() => {
            document.getElementById('audioPlayer').play()
        }, 5000)
    } else {
        document.getElementById('audioPlayer').play()
    }

    document.getElementById('microphone').disabled = true
    speechRecognizer.recognized = async (s, e) => {
        if (e.result.reason === SpeechSDK.ResultReason.RecognizedSpeech) {
            let userQuery = e.result.text.trim()
            if (userQuery === '') {
                return
            }

            // Auto stop microphone when a phrase is recognized, when it's not continuous conversation mode
            if (!document.getElementById('continuousConversation').checked) {
                document.getElementById('microphone').disabled = true
                speechRecognizer.stopContinuousRecognitionAsync(
                    () => {
                        document.getElementById('microphone').innerHTML = 'Start Microphone'
                        document.getElementById('microphone').disabled = false
                    }, (err) => {
                        console.log("Failed to stop continuous recognition:", err)
                        document.getElementById('microphone').disabled = false
                    })
            }

            handleUserQuery(userQuery)
        }
    }

    speechRecognizer.startContinuousRecognitionAsync(
        () => {
            document.getElementById('microphone').innerHTML = 'Stop Microphone'
            document.getElementById('microphone').disabled = false
        }, (err) => {
            console.log("Failed to start continuous recognition:", err)
            document.getElementById('microphone').disabled = false
        })
}

window.updataEnableByod = () => {
    if (document.getElementById('enableByod').checked) {
        document.getElementById('cogSearchConfig').hidden = false
    } else {
        document.getElementById('cogSearchConfig').hidden = true
    }
}

window.updateTypeMessageBox = () => {
    if (document.getElementById('showTypeMessage').checked) {
        document.getElementById('userMessageBox').hidden = false
        document.getElementById('userMessageBox').addEventListener('keyup', (e) => {
            if (e.key === 'Enter') {
                const userQuery = document.getElementById('userMessageBox').value
                if (userQuery !== '') {
                    handleUserQuery(userQuery.trim('\n'))
                    document.getElementById('userMessageBox').value = ''
                }
            }
        })
    } else {
        document.getElementById('userMessageBox').hidden = true
    }
}

window.updateLocalVideoForIdle = () => {
    if (document.getElementById('useLocalVideoForIdle').checked) {
        document.getElementById('showTypeMessageCheckbox').hidden = true
    } else {
        document.getElementById('showTypeMessageCheckbox').hidden = false
    }
}

// Make video background transparent by matting
function makeBackgroundTransparent(timestamp) {
    // Throttle the frame rate to 30 FPS to reduce CPU usage
    if (timestamp - previousAnimationFrameTimestamp > 30) {
        video = document.getElementById('videoPlayer')
        tmpCanvas = document.getElementById('tmpCanvas')
        tmpCanvasContext = tmpCanvas.getContext('2d', { willReadFrequently: true })
        tmpCanvasContext.drawImage(video, 0, 0, video.videoWidth, video.videoHeight)
        if (video.videoWidth > 0) {
            let frame = tmpCanvasContext.getImageData(0, 0, video.videoWidth, video.videoHeight)
            for (let i = 0; i < frame.data.length / 4; i++) {
                let r = frame.data[i * 4 + 0]
                let g = frame.data[i * 4 + 1]
                let b = frame.data[i * 4 + 2]
                if (g - 150 > r + b) {
                    // Set alpha to 0 for pixels that are close to green
                    frame.data[i * 4 + 3] = 0
                } else if (g + g > r + b) {
                    // Reduce green part of the green pixels to avoid green edge issue
                    adjustment = (g - (r + b) / 2) / 3
                    r += adjustment
                    g -= adjustment * 2
                    b += adjustment
                    frame.data[i * 4 + 0] = r
                    frame.data[i * 4 + 1] = g
                    frame.data[i * 4 + 2] = b
                    // Reduce alpha part for green pixels to make the edge smoother
                    a = Math.max(0, 255 - adjustment * 4)
                    frame.data[i * 4 + 3] = a
                }
            }

            canvas = document.getElementById('canvas')
            canvasContext = canvas.getContext('2d')
            canvasContext.putImageData(frame, 0, 0);
        }

        previousAnimationFrameTimestamp = timestamp
    }

    window.requestAnimationFrame(makeBackgroundTransparent)
}

window.addEventListener('message', function(event) {
    if (event.origin !== window.location.origin) {
        // Ignore messages from different origins for security reasons
        return;
    }

    const data = event.data;
    console.log('Received data:', data);

    // Handle the received data (jobTitle and skills)
    extractedCV = data.cv;
    extractedJD = data.jd;
    console.log(extractedCV);
    console.log("123");
    console.log(extractedJD);

});
