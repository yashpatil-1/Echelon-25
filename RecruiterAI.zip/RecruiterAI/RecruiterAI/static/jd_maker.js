document.addEventListener("DOMContentLoaded", function () {
  const textInputFields = document.querySelectorAll('input[type="text"]');
  textInputFields.forEach((inputField) => {
    inputField.setAttribute('autocomplete', 'off');
  });

  // IDs and types
  const input_ids = ["location", "ename", "d-level", "LOS", "techsk", "yexp", "mname", "language"];
  const input_types = ["text", "text", "text", "text", "text", "text", "text", "text"];

  // Reusable toast display
  function displayMessage(type, message) {
    let toastContainer = document.getElementById("toast-container");
    if (!toastContainer) {
      toastContainer = document.createElement("div");
      toastContainer.id = "toast-container";
      document.body.appendChild(toastContainer);
    }

    const toast = document.createElement("div");
    toast.classList.add("toast", type === "success" ? "toast-success" : "toast-error");
    toast.innerText = message;
    toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.classList.add("fade-out");
      setTimeout(() => {
        toast.remove();
      }, 500);
    }, 5000);
  }

  // Validation function
  function validateForm() {
    let isValid = true;
    input_ids.forEach((id) => {
      const inputElement = document.getElementById(id);
      const value = inputElement.value.trim();

      if (value === "") {
        displayMessage("error", `${id.replace('-', ' ')} cannot be empty.`);
        inputElement.classList.add("input-error");
        isValid = false;
      } else {
        inputElement.classList.remove("input-error");
      }

      // Additional numeric check for yexp
      if (id === "yexp" && (value === "" || isNaN(value))) {
        displayMessage("error", "Years of experience must be a valid number.");
        inputElement.classList.add("input-error");
        isValid = false;
      }
    });
    return isValid;
  }

  // Single event listener for "Generate Now!"
  document.getElementById("submit").addEventListener("click", function (event) {
    event.preventDefault();

    // 1) Validate
    if (!validateForm()) {
      return; // Stop if invalid
    }

    // 2) Disable button and show loader
    this.disabled = true;
    const submitLoader = document.getElementById("submit-loader");
    submitLoader.style.display = "inline-block";

    const downloadLinkContainer = document.getElementById("download-link-container");
    const viewLinkContainer = document.getElementById("view-link-container");
    downloadLinkContainer.style.display = "none";
    viewLinkContainer.style.display = "none";

    // 3) Prepare form data
    const formData = new FormData();
    input_ids.forEach((id) => {
      formData.append(id, document.getElementById(id).value.trim());
    });

    // 4) Send AJAX (XHR) request to your API
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/jd_maker/generate_job_description", true);
    xhr.responseType = "blob";
    xhr.onreadystatechange = function () {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
          // 5) On success
          const fileURL = URL.createObjectURL(xhr.response);
          displayMessage("success", "Job description generated successfully!");

          // Re-enable button
          submitLoader.style.display = "none";
          document.getElementById("submit").disabled = false;

          // Show "Download JD" link
          const downloadLink = document.createElement("a");
          downloadLink.href = fileURL;
          const today = new Date();
          const formattedDate =
            String(today.getDate()).padStart(2, '0') + '/' +
            String(today.getMonth() + 1).padStart(2, '0') + '/' +
            today.getFullYear();
          downloadLink.download = "Job_Description_" + formattedDate + ".pdf";
          downloadLink.textContent = "Download JD";
          downloadLinkContainer.innerHTML = "";
          downloadLinkContainer.style.display = "inline-block";
          downloadLinkContainer.appendChild(downloadLink);

          // Show "View JD" link
          viewLinkContainer.style.display = "inline-block";
          viewLinkContainer.onclick = function (e) {
            e.preventDefault();
            const containerDoc = document.querySelector(".container_doc");
            containerDoc.innerHTML = "";
            const iframe = document.createElement("iframe");
            iframe.src = fileURL;
            iframe.width = "100%";
            iframe.height = "100%";
            iframe.style.border = "none";
            containerDoc.appendChild(iframe);
          };

        } else {
          // 6) On error
          displayMessage("error", "Failed to generate PDF. Please try again.");
          submitLoader.style.display = "none";
          document.getElementById("submit").disabled = false;
        }
      }
    };

    xhr.onerror = function () {
      displayMessage("error", "An error occurred while sending the request.");
      submitLoader.style.display = "none";
      document.getElementById("submit").disabled = false;
    };

    xhr.send(formData);
  });

  // ========================
  // Template upload logic...
  // ========================

  const dropboxTemplate = document.getElementById("dropbox-template");
  const fileInputTemplate = document.getElementById("file-input-template");
  const name_template = document.getElementById('name_template');

  // If you have drag & drop, you might want to handle 'dragover' as well
  dropboxTemplate.addEventListener("drop", (e) => {
    e.preventDefault();
    e.stopPropagation();
    dropboxTemplate.classList.remove("dragover");
    const file = e.dataTransfer.files[0]; // <-- typically e.dataTransfer instead of e.target.files

    if (file) {
      const reader = new FileReader();
      reader.onload = function (event) {
        const data = new Uint8Array(event.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const json = XLSX.utils.sheet_to_json(worksheet);
        generateQuestions(json);
      };
      reader.readAsArrayBuffer(file);
    }
  });

  dropboxTemplate.addEventListener("click", () => {
    fileInputTemplate.click();
  });

  fileInputTemplate.addEventListener("change", function (event) {
    const file = event.target.files[0];
    if (!file) return;

    name_template.style.display = 'block';
    name_template.textContent = "Template uploaded";

    const reader = new FileReader();
    reader.onload = function (event) {
      const data = new Uint8Array(event.target.result);
      const workbook = XLSX.read(data, { type: 'array' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const json = XLSX.utils.sheet_to_json(worksheet);
      generateQuestions(json);
      document.getElementById("template_popup").style.display = 'none';
    };
    reader.readAsArrayBuffer(file);
  });

  document.getElementById("download-template").addEventListener("click", function (e) {
    e.preventDefault();
    const data = [
      ["FormFields", "Options"],
      ["Location", ""],
      ["Job Title", ""],
      ["Designation Level", ""],
      ["Line Of Service", ""],
      ["Strategic Business Unit", ""],
      ["Desired Skills", ""],
      ["Years of experience", ""],
      ["Manager name", ""],
      ["Language", ""]
    ];

    const ws = XLSX.utils.aoa_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
    XLSX.writeFile(wb, "template.xlsx");
  });

  document.getElementById("submit-template").addEventListener("click", (e) => {
    e.preventDefault();
    // If user wants to continue with the default fields,
    // just hide the popup
    document.getElementById("template_popup").style.display = 'none';
    document.getElementById("blurdiv").style.filter = 'none';
  });

  // The function that generates dynamic questions from the uploaded Excel
  function generateQuestions(data) {
    const container = document.getElementById("jd_form");
    container.innerHTML = ''; // Clear previous questions

    data.forEach((row, index) => {
      const formfield = row.FormFields;
      const options = row.Options;

      const formfieldWrapper = document.createElement("div");
      formfieldWrapper.classList.add("fieldset");

      const label = document.createElement("label");
      label.textContent = formfield;
      label.setAttribute("for", "formfield-" + index);

      let input;
      if (options) {
        // Create a dropdown
        input = document.createElement("select");
        const defaultOption = document.createElement("option");
        defaultOption.text = "Select an option";
        defaultOption.disabled = true;
        defaultOption.selected = true;
        input.appendChild(defaultOption);

        const splittedOptions = row.Options.split(',');
        splittedOptions.forEach((option) => {
          const dropdownOption = document.createElement("option");
          dropdownOption.value = option.trim();
          dropdownOption.textContent = option.trim();
          input.appendChild(dropdownOption);
        });
      } else {
        // Create a text input
        input = document.createElement("input");
        input.type = "text";
        input.placeholder = "Enter the " + formfield;
      }

      if (input) {
        input.id = formfield;
        input.name = formfield;
        formfieldWrapper.appendChild(label);
        formfieldWrapper.appendChild(input);
      }

      container.appendChild(formfieldWrapper);
    });

    // Once questions are generated, hide blur
    document.getElementById("blurdiv").style.filter = 'none';
  }

});
